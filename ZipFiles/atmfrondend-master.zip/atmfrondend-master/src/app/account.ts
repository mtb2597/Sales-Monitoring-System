
export interface Account {
    userName?: string;
    accountNumber?: number;
    accountPin?: number;
    availableBalance?: number;
    totalBalance?: number;
}
