
/* for orange color object*/

$(document).ready(function(){
       $(".highlight,.current").fadeToggle(1000).fadeToggle(1000); 
       
    });
 
   


   


