export class Mobile {

    mn:Number;
    imeino:Number;

    
       


}
